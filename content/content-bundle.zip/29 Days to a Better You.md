202302182230

# 29 Days to a Better You

[29 Days to a Better You](https://www.youtube.com/watch?v=NrgnbFmVm_E)
Are you wondering how to form a new habit? Try committing your life to a desired change for just the next 29 days.

- [[202302182240#29 Days to a Paperless Backpack]]
  - The Backpack method
- [[202302190010#29 Days to Daily Stoic]]
- 29 Days to a Vitamin Tracker
  - Using a Daylio database
- 29 Days to a Gratitude Journal
- Grew out of [30 Days to Success – Steve Pavlina](https://stevepavlina.com/blog/2005/04/30-days-to-success/)
- Declutter home - complete 1 project for 29 days
- Get in shape - go to the gym for 29 days
- Become an early riser - wake up at 5am for 29 days
- Become a better reader - read something every day for 29 days
- Change eating habits - committed to no sugar for 29 days

- [ ] The "29 days template"
- [ ] Use Templatr to generate the next 7–29 days

# Template

```dataviewjs
const HEADERS = ["", "Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]
const el = dv.markdownTable(HEADERS, 
  Object.values(
    dv.current().file.tasks.array()
      .filter(task => task.completion)
      .reduce((memo, task) => {
        const week = `W${task.completion.weekNumber}`
        const day = task.completion.weekday
        const minuteOfDay = task.completion.hour * 60 + task.completion.minute
        memo[week] = memo[week] || [ week ]
        memo[week][day] = memo[week][day] || []
        memo[week][day].push(minuteOfDay > 0 ? '▪' : '▫')
        return memo
      }, {})
  )
  .map(row => HEADERS.map((_, index) => {
    const col = row[index] || ''
    if (typeof col === 'string') return col
    return col.join('')
  }))
)
dv.el('div', el)
```

- [ ] Receipt MEGA IMAGE 2023-02-17 24.68 [completion:: 2023-02-18T22:50]
- [ ] [completion:: 2023-02-19]
- [ ] [completion:: 2023-02-20]
- [ ] [completion:: 2023-02-21]
- [ ] [completion:: 2023-02-22]
- [ ] [completion:: 2023-02-23]

## Docs
- Using Dataview
  - [Metadata on Tasks and Lists - Dataview](https://blacksmithgu.github.io/obsidian-dataview/annotation/metadata-tasks/)
  - [Data Types - Dataview](https://blacksmithgu.github.io/obsidian-dataview/annotation/types-of-metadata/)
  - [Data Arrays - Dataview](https://blacksmithgu.github.io/obsidian-dataview/api/data-array/)
  - [Codeblock Reference - Dataview](https://blacksmithgu.github.io/obsidian-dataview/api/code-reference/#dvtableheaders-elements)
- With DateTime API from [luxon 3.2.1 | Documentation](https://moment.github.io/luxon/api-docs/index.html#datetime)

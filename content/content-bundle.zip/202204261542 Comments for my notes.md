Thought I had found a markdown collaboration tool in [[202204101343 Collaborate on Markdown]], what I'd actually like to have is a system for adding "comments in the margins" or "annotations" to notes published on GitHub pages.

- [Pundit Annotator | Pundit](https://thepund.it/annotator-web-annotation/) — looks good for personal use, may be used in a group, but it's not quite what I'm looking for

- [Markup.io: Easiest Way to Leave Feedback on Digital Content](https://www.markup.io/) — looks a lot closer to what I'm looking for, but relies on an embedded version of the content; may be a gap-filler unless I find a different working solution
  + [Best Practices – MarkUp](https://support.markup.io/hc/en-us/sections/4413415117587-Best-Practices?_ga=2.236554373.506593234.1650977070-1203226931.1650977070)
  + [About Markup.io Team](https://www.markup.io/about-us/)

- [openannotation/annotator: Annotation tools for the web. Select text, images, or (nearly) anything else, and add your notes.](https://github.com/openannotation/annotator) — Closer to what I was looking for, but the latest release is from Feb 26, 2015
  + [Annotator - Annotating the Web](http://annotatorjs.org/) — Homepage for the library
  + [AnnotateIt](https://annotateit.org/) — Now defunct service that acted as the storage for AnnotatorJS

- [Hypothesis](https://web.hypothes.is/) — The service that succeeded the AnnotateIt.
  - After browsing through their website a bit, it seems that this is an organization with a vision aligned with mine. (Though not coinciding.)
  - Furthermore, the service is easy enough to use without installing anything.
  - While it works out of the box, it may become tricky with websites that rely of history pushing and changing the contents dynamically.
    + Here it is upon Andy's Notes — [Via: About these notes](https://via.hypothes.is/https://notes.andymatuschak.org/About_these_notes)

There are a few things to note when using Hypothesis, especially around URLs and versioning. I'm not sure how changing an entire page (for example after implementing feedback) would affect the rest of the annotations.
- Keeping versioned references might be a good idea, however such versions may not "carry-forward" the conversations, unless somehow directly instructing Hypothesis about it. It's something to ponder for the future. Right now it looks like a good start for what I need.


Hello! These are Mihai's public notes, a lot of brown field and a few budding seeds, my future garden.

Be kind, rewind!

And also consider beginning by giving me feedback (or saying hello) here: [[202303192135#Please hypothesize over my notes]]

PS. We're getting [deep innit](https://collectiveiq.wordpress.com/2016/04/16/game-changer-hypothes-is-announces-direct-linking-across-the-web/). 
- [ ] Is there hypothesis in Obsidian? Can we bring it?
